from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient, errors
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests

# ---------- MONGODB CONNECTION ----------
try:
    client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=5000)
    client.server_info()  # Trigger exception if cannot connect
    db = client["femishield_db"]
    users_collection = db["users"]
    assessments_collection = db["assessments"]
    print("✅ Connected to MongoDB successfully!")
except errors.ServerSelectionTimeoutError:
    print("❌ Could not connect to MongoDB. Please make sure MongoDB is running.")
    exit()

# ---------- SIGN UP ----------
@app.route("/signup", methods=["POST"])
def signup():
    data = request.json
    name = data.get("name")
    email = data.get("email")
    password = data.get("password")

    if not name or not email or not password:
        return jsonify({"success": False, "message": "All fields are required."})

    if users_collection.find_one({"email": email}):
        return jsonify({"success": False, "message": "Email already registered."})

    hashed_password = generate_password_hash(password)
    users_collection.insert_one({
        "name": name,
        "email": email,
        "password": hashed_password
    })

    return jsonify({"success": True, "message": "User registered successfully!"})

# ---------- LOGIN ----------
@app.route("/login", methods=["POST"])
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"success": False, "message": "All fields are required."})

    user = users_collection.find_one({"email": email})
    if not user or not check_password_hash(user["password"], password):
        return jsonify({"success": False, "message": "Invalid email or password."})

    return jsonify({"success": True, "message": f"Welcome {user['name']}!"})

# ---------- ASSESSMENT FUNCTION ----------
def save_assessment(email, personal_info, answers, total_score, risk_level, assessment_type):
    # Fetch previous assessment
    previous = assessments_collection.find({"email": email, "type": assessment_type}).sort("_id", -1).limit(1)
    prev_score = None
    for p in previous:
        prev_score = p["totalScore"]

    # Save current assessment
    assessments_collection.insert_one({
        "email": email,
        "personalInfo": personal_info,
        "answers": answers,
        "totalScore": total_score,
        "riskLevel": risk_level,
        "type": assessment_type
    })

    # Compare with previous score (just increase/decrease/same)
    comparison_message = ""
    if prev_score is not None:
        if total_score < prev_score:
            comparison_message = "🎉 Great! Your risk level has decreased compared to last time."
        elif total_score > prev_score:
            comparison_message = "⚠️ Your risk level has increased compared to last time. Take more care!"
        else:
            comparison_message = "Your risk level is the same as last time."

    return comparison_message

# ---------- GENERAL ASSESSMENT ----------
@app.route("/assessment", methods=["POST"])
def general_assessment():
    data = request.json
    email = data.get("email")
    personal_info = data.get("personalInfo")
    answers = data.get("answers")
    total_score = data.get("totalScore")
    risk_level = data.get("riskLevel")

    if not email or not personal_info or not answers:
        return jsonify({"success": False, "message": "Incomplete assessment data."})

    comparison_message = save_assessment(email, personal_info, answers, total_score, risk_level, "general")

    return jsonify({
        "success": True,
        "message": "Assessment saved successfully!",
        "comparison": comparison_message
    })

# ---------- BREAST CANCER ASSESSMENT ----------
@app.route("/bcancer", methods=["POST"])
def breast_cancer_assessment():
    data = request.json
    email = data.get("email")
    personal_info = data.get("personalInfo")
    answers = data.get("answers")
    total_score = data.get("totalScore")
    risk_level = data.get("riskLevel")

    if not email or not personal_info or not answers:
        return jsonify({"success": False, "message": "Incomplete breast cancer assessment data."})

    comparison_message = save_assessment(email, personal_info, answers, total_score, risk_level, "bcancer")

    return jsonify({
        "success": True,
        "message": "Breast cancer assessment saved successfully!",
        "comparison": comparison_message
    })

# ---------- HOME ROUTE ----------
@app.route("/")
def home():
    return "FemiShield Backend Running 🌸"

if __name__ == "__main__":
    app.run(debug=True)
